package com.ejercicio.data;

public interface IMetodo {
	
	//Paso 1: Crear un metodo llamado "metodo" sin parametros que devuelva cadena
	
	
	
	//Paso 2: Crear un metodo llamado "metodo" con una cadena como parametro que devuelva cadena
	
	
	//Paso 3: Crear un metodo llamado "metodoPadre" con una cadena y un objeto entero como parametro
	//devuelve cadena
	
	

}
