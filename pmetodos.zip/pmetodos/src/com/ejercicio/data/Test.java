package com.ejercicio.data;

public class Test {
	
	public static void main(String args[]) {
		//Paso 1. Muestra por pantalla que tipos de variables compilarian
		// <tipo> variable = new MetodoHijo();
		//System.out.println("Object "+"MetodoHijo "+"Metodo "+"IMetodo "+"MetodoPadre");
		//Paso 2. �Como conseguiriamos un objeto Metodo?�Y de MetodoPadre?
		//NO HAY FORMA, no podemos utilizar directamente el constructor de Metodo, ni de MetodoPadre
	    //System.out.println(MetodoHijo.metodoEstatico("main"));
	   
	    
	}

}
