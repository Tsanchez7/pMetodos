

package com.ejercicio.data;


public abstract class MetodoPadre {
	//Paso 1: Crear un metodo  privado est�tico llamado "metodoEstatico" que tenga como par�metro una cadena
	// mostrar� un syso con la concatenaci�n de la cadena y "Metodo Padre"
	

	//Paso 2: Crear un metodo protegido llamado "metodoPadre" sin par�metros
	// que devuelva "Metodo Padre"
	
	
	//Paso 3: Sobrecargar el metodo anterior pasando una cadena 
	// que muestre por consola la cadena de invocar al metodo anterior
	// y que devuelva la concatenaci�n de la cadena(palabra) y lo que devuelva 
	// el metodo padre sin parametros
	
	
	//Paso 4: Crear un metodo protegido y final llamado "metodoPadre2" sin par�metros
	// que invoque al m�todo est�tico de esta clase con una cadena cualquiera.
	
	
	
	
	//Paso 5: Crear un metodo abstracto metodoPadre2, que tenga como parametro una cadena
	
	
	
	//Paso 6: Crear un metodo abstracto metodoPadre2, que tenga como parametro una cadena y un entero primitivo
	
	
	
}
