package com.ejercicio.data;

public class MetodoHijo extends Metodo {

	// Paso 1: Crear un metodo publico est�tico llamado "metodoEstatico" que tenga
	// como
	// par�metro una cadena
	// mostrar� un syso con la concatenaci�n de "Metodo Est�tico Hijjo" y de la
	// cadena
	// El m�todo devolver� esta concatenaci�n.
	//METODO INDEPENDIENTE, NO HAY SOBREESCRITURA
	
	// Paso 2: Implementar todos los m�todos necesarios para que sea una clase
	// concreta
	// Si tienen parametros que se concatenen con la cadena "Hijo"
	// y si devuelven algo que devuelvan ese resultado, si no devuelven nada
	// que lo muestren por pantalla
	// Hay que indicar mediante un syso, en qu� clase esta la definici�n del m�todo

	

	


	// Paso 3: Sobreescribir el metodo "metodo" sin parametros 
	// que invoque al m�todo est�tico de esta clase con una cadena cualquiera.
	// Devolver� el resultado del m�todo estatico y con la suma de " Metodo Sin
	// parametros";	

	

}
