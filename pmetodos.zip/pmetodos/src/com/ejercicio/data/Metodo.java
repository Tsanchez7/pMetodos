package com.ejercicio.data;

public abstract class Metodo extends MetodoPadre implements IMetodo{

	//Paso 1: Crear un metodo privado est�tico llamado "metodoEstatico" que tenga como par�metro una cadena
	// mostrar� un syso con la concatenaci�n de "Metodo Est�tico" y de la cadena
	// El m�todo devolver� esta concatenaci�n.
	
	
	//Paso 2: Implementar el m�todo "metodo" 
	//que invoque al m�todo est�tico de esta clase con una cadena cualquiera.
	//Devolver� el resultado del m�todo estatico y con la suma de " Metodo Sin parametros";
	
	
	//Paso 3: Sobreescribir el metodo que se pueda sin parametros haciendolo publico
	//Devolvera la cadena "Metodo"
	//NO SE PODR�A HACER PRIVADO PORQUE SIEMPRE HAY QUE DAR IGUAL O MAS ACCESO QUE EL INDICADO EN EL ORIGINAL
	
	
	
	//Paso 2: �Poqu� no compila? 
	//Sin implementar m�todos nuevos arreglar el fallo de compilacion
	//DECLARARLA ABSTRACTA

	//Paso 3: Crear un metodo abstracto metodoPadre2, que tenga como parametro una cadena y un objeto entero
	

}
